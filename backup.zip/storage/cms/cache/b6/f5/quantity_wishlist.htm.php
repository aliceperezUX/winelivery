<?php 
class Cms5952bdefa29d7540528700_d9fef347c49346ca0fa6211ea6e94299Class extends \Cms\Classes\PartialCode
{

}
