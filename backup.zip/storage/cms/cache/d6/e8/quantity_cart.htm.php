<?php 
class Cms5952bdefa420c704296026_a830a123387a4fd7a9c86d9c1b621723Class extends \Cms\Classes\PartialCode
{

}
