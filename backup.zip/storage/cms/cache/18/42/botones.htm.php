<?php 
class Cms5952bdef76df7685279893_8b01b90c519aef1b4e03901e549b00caClass extends \Cms\Classes\PartialCode
{

}
