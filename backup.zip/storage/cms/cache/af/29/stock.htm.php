<?php 
class Cms5952bdef750b6182271241_7d4dec81f242430df40ed6ebb14675a0Class extends \Cms\Classes\PartialCode
{

}
